=============
Django Statsd
=============

Documentation is on `Read the Docs <https://django-statsd.readthedocs.org/>`_.

-------
License
-------

BSD and MPL

Portions of this are from commonware:

https://github.com/jsocol/commonware/blob/master/LICENSE
