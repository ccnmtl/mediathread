
from setuptools import setup, find_packages

setup(
    name="django-modelversions",
    version="1.0",
    author="rpercy",
    url="http://code.google.com/p/django-modelversions/",
    install_requires = [],
    scripts = [],
    platforms = ["any"],
    zip_safe=False,
    packages=['modelversions'],
    include_package_data=True,
    )
