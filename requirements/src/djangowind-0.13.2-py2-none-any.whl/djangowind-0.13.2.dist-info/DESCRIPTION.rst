Django Authentication backend for CU WIND and associated helpers


