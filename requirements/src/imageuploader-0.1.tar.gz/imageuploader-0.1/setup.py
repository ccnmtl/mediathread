#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name="imageuploader",
    version="0.1",
    description="simple wrapper on uploading images to the CCNMTL repository",
    long_description="simple wrapper on uploading images to the CCNMTL repository",
    author="anders",
    author_email="anders@columbia.edu",
    url="http://microapps.org",
    license="BSD",

    install_requires = [
        "restclient >= 0.9.7",
    ],
    include_package_data = True,
    package_data = {'':['*.kid',],
                    },
    zip_safe=False,
    packages=find_packages(exclude=["tgtest","tgtest.*"]),
    )
