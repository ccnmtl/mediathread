BSD and MPL

Portions of this are from commonware:

https://github.com/jsocol/commonware/blob/master/LICENSE
