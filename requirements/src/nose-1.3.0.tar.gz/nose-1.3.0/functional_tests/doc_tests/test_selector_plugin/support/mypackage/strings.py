def cat(a, b):
    return "%s%s" % (a, b)
