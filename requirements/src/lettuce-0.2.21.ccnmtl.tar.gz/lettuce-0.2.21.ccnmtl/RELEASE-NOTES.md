# Release Notes

## barium

### 0.1.20

1. Supporting multi line steps [like in cucumber](https://github.com/aslakhellesoy/cucumber/wiki/multiline-step-arguments), [thanks](https://github.com/gabrielfalcao/lettuce/pull/104) to [@pib](https://github.com/pib) for his terrific code.
2. Now we have release notes :)
