.. include:: ../README.rst

Installation
============

Install django-appconf with your favorite Python package manager, e.g.::

    pip install django-appconf

Contents
========

.. toctree::
  :maxdepth: 1

  usage
  reference
  changelog
