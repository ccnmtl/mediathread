#: E261
pass # an inline comment
#: E262
x = x + 1  #Increment x
#: E262
x = x + 1  #  Increment x
