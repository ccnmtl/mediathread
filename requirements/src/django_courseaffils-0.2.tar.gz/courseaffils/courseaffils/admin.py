from django.contrib import admin
from courseaffils.models import Course

admin.site.register(Course)
