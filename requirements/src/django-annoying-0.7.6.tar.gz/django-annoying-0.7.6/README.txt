Django Annoying Application
===========================

This is a django application that tries to eliminate annoying things in the
Django framework.

For installation instructions see the file "INSTALL.txt" in this directory. You
need the last development version of django to use this application.
