from compressor.filters.base import (FilterBase, CallbackOutputFilter,
                                     CompilerFilter, FilterError)
