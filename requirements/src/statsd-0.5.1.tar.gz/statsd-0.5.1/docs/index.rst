.. Python StatsD documentation master file, created by
   sphinx-quickstart on Mon Apr  9 15:47:23 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python StatsD's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   configure.rst
   types.rst
   timing.rst
   reference.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

