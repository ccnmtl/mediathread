__author__ = 'Daniel Lindsley, Cody Soyland, Matt Croydon, Josh Bohde & Issac Kelly'
__version__ = (0, 9, 12, 'alpha')
