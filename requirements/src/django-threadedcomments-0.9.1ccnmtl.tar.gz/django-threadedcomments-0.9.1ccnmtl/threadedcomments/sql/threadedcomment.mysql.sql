CREATE INDEX `threadedcomments_comment_tree_path` ON `threadedcomments_comment` (`tree_path`(255));
