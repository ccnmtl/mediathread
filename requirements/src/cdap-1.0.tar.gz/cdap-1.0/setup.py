from setuptools import setup, find_packages


import os
execfile(os.path.join("cdap", "release.py"))

setup(
    name="cdap",
    version=version,
    
    # uncomment the following lines if you fill them out in release.py
    #description=description,
    #author=author,
    #author_email=email,
    #url=url,
    #download_url=download_url,
    #license=license,
    
    install_requires = [
    "selector >= 0.8.11",
    "PasteScript >= 0.9.7",
    "Paste >= 0.9.7",
    ],
    scripts = [],
    zip_safe=False,
    packages=find_packages(),
    keywords = [
    ],
    classifiers = [
        'Development Status :: 3 - Alpha',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    test_suite = 'nose.collector',
    entry_points="""
    [paste.app_factory]
    main=cdap.wsgiapp
    """
    )
    
