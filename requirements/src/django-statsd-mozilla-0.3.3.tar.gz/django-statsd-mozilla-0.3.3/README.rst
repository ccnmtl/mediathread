Django Statsd
=============

Integration between statsd and django. It allows you to use different clients,
sends timings as middleware and integrates with django debug toolbar.

Credits:

- jbalogh and jsocol for statsd and commonware, which I just ripped parts out
  of and put in here.
- robhudson for django-debug-toolbar

Changes
-------

0.3:

- added in logging handler for logging error counts to stats

For more see our docs at: http://readthedocs.org/docs/django-statsd/en/latest/
