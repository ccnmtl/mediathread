#: E301
class X:

    def a():
        pass
    def b():
        pass
#: E301
class X:

    def a():
        pass
    # comment
    def b():
        pass
#:


#: E302
def a():
    pass

def b():
    pass
#: E302
def a():
    pass

# comment

def b():
    pass
#:


#: E303
print



print
#: E303
print



# comment

print
#: E303
def a():
    print


    # comment

    print
#:


#: E304
@decorator

def function():
    pass
#:
