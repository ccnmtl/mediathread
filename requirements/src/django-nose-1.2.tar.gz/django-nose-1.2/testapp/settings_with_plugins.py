from .settings import *


NOSE_PLUGINS = [
    'testapp.plugins.SanityCheckPlugin'
]
