#: E111
if x > 2:
  print x
#: E111
if True:
     print
#: E112
if False:
print
#: E113
print
    print
