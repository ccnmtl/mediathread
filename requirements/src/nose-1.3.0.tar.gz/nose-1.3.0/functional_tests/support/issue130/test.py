def setup():
   raise "KABOOM"

def test_foo():
    assert(1==1)
