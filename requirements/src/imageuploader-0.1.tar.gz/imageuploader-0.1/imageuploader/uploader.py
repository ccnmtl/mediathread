from restclient import POST

class Uploader:
    def __init__(self,upload_uri="http://www.columbia.edu/cgi-bin/ccnmtl/amsterdam/upload.cgi"):
        self.upload_uri = upload_uri

    def upload(self,filename,data):
        return POST(self.upload_uri,
                    params={'type' : 'image'},
                    files={'file' : {'filename' : filename,
                                     'file' : data}},
                    async=False)
    

# provide a simple functional interface while we're at it
def upload_image(filename,data,upload_uri="http://www.columbia.edu/cgi-bin/ccnmtl/amsterdam/upload.cgi"):
    u = Uploader(upload_uri)
    return u.upload(filename,data)
    
