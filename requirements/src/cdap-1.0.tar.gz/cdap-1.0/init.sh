#!/bin/bash
cd $1
rm -rf working-env
python workingenv.py working-env
source working-env/bin/activate
easy_install -H None -f eggs eggs/*.egg

