See doc/main.txt and doc/intro.txt

For installation information, see INSTALL.txt
