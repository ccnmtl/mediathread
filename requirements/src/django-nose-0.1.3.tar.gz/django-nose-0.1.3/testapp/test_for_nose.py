"""
Django's test runner won't find this, but nose will.
"""


def test_addition():
    assert 1 + 1 == 2
