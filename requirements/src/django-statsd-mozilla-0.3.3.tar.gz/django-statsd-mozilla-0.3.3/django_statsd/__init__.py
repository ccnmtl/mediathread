from django_statsd import patches
from django_statsd import clients
