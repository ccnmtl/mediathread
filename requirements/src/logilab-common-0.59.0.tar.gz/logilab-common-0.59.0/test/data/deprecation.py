# placeholder used by unittest_deprecation

def moving_target():
    pass
