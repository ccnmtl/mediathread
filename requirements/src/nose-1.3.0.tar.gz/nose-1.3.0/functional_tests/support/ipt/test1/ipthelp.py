print "1help imported"
def help():
    print "1help called"
    pass
