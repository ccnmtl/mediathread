"""This is gramatically correct, but it's still a SyntaxError"""
__revision__ = None
return
