def test():
    print "something"
    raise IOError(42, "test")
